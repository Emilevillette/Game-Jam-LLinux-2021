<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.3" name="items" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="../images/items.png" width="128" height="128"/>
</tileset>
